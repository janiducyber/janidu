# megarunauto
Dialog Mega Run is a mobile based adventure game, exclusively available to Dialog customers, where players will run through iconic locations in Sri Lanka trying not to stumble over oncoming obstacles. Dialog Mega Run lets players win free data, along with many more amazing gifts while playing
